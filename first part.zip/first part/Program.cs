﻿using System;

namespace HelloWorld
{
    
    public enum Department
    {
        ComputerScience,
        Machinelearning,
        WebDevelopment
    }

    class Person
    {
        
        public string Name { get; set; }

       
        public Person()
        {
            Name = null;
        }

        
        public Person(string name)
        {
            Name = name;
        }
    }

    class Student : Person
    {
        
        public string Registration { get; set; }
        public int Age { get; set; }
        public Department Department { get; set; }

        
        public Student() : base() 
        {
            Registration = null;
            Age = 0;
            Department = Department.ComputerScience; 
        }

      
        public Student(string name, string r, int ag, Department dep) : base(name) 
        {
            Registration = r;
            Age = ag;
            Department = dep;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            
            Student std = new Student("Zaeem Tahir", "233567", 20, Department.ComputerScience);

            Console.WriteLine("Name of the Student is : " + std.Name);
            Console.WriteLine("Registration of the Student is : " + std.Registration);
            Console.WriteLine("Age of the Student is : " + std.Age);
            Console.WriteLine("Department of the Student is : " + std.Department);
        }
    }
}
